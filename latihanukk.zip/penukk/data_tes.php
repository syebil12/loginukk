<?php
include "koneksi.php";
$data = mysqli_query($koneksi, "SELECT * FROM tes_siswa");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Tes Siswa</title>
    <style>
        table { width: 80%; margin: auto; border-collapse: collapse; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
        th { background-color: #f2f2f2; }
        h2 { text-align: center; }
    </style>
</head>
<body>
    <h2>Data Tes Siswa</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>NIS</th>
                <th>Nomor Tes</th>
                <th>Tanggal Tes</th>
                <th>Bersedia</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while ($row = mysqli_fetch_assoc($data)) {
                echo "<tr>
                        <td>$no</td>
                        <td>{$row['nis']}</td>
                        <td>{$row['nomor_tes']}</td>
                        <td>{$row['tanggal_tes']}</td>
                        <td>{$row['bersedia']}</td>
                    </tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
</body>
</html>
