<?php
include "koneksi.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST['Username'];
    $password = $_POST['Password'];
    $status   = $_POST['status'];

    $query = "SELECT * FROM user WHERE username='$username' AND password='$password' AND status='$status'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['username'] = $username;
        echo "<script>alert('Login berhasil!'); window.location.href='menuutama.php';</script>";
    } else {
        echo "<script>alert('Login gagal! Periksa kembali data Anda.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login User</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="login-container">
        <form method="POST" class="login-box">
            <img src="LogoRPL.jpeg" alt="Logo" class="logo">
            <p class="subtitle">Mulai Akses Akun User</p>
            <h2>Login user</h2>

            <input type="text" name="Username" placeholder="Username" required>
            <input type="password" name="Password" placeholder="Password" required>

            <select name="status" required>
                <option value="">--Pilih Peran--</option>
                <option value="siswa">Siswa</option>
                <option value="guru">Guru</option>
            </select>

            <button type="submit" class="btn-login">Login</button>

            <p class="register-text">Apakah Anda Belum Memiliki Akun User?</p>
            <a href="register.php" class="btn-register">Buat Akun User</a>
            <br><br>
            <a href="menuutama.php">Balik Ke Home</a>
        </form>
    </div>
</body>
</html>
