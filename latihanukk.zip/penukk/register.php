<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST['Username'];
    $password = $_POST['Password'];
    $status   = $_POST['status'];

    // Upload foto
    $foto_name = $_FILES['foto']['name'];
    $tmp_name  = $_FILES['foto']['tmp_name'];
    $upload_dir = "folder_upload_foto/";

    // Buat folder jika belum ada
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Cek apakah file berhasil dipindahkan
    if (move_uploaded_file($tmp_name, $upload_dir . $foto_name)) {
        $query = "INSERT INTO user (username, password, foto, status) 
                  VALUES ('$username', '$password', '$foto_name', '$status')";
        $result = mysqli_query($koneksi, $query);

        if ($result) {
            echo "<script>alert('Pendaftaran berhasil!'); window.location.href='login.php';</script>";
        } else {
            echo "<script>alert('Pendaftaran gagal: " . mysqli_error($koneksi) . "');</script>";
        }
    } else {
        echo "<script>alert('Upload foto gagal!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register User</title>
    <link rel="stylesheet" href="register.css">
</head>
<body>
    <nav>
        <div class="logo">
            <img src="LogoRPL.jpeg" alt="Logo" class="logo-img">
            <span class="title">Register User</span>
        </div>
        <a href="#" class="nav-home">Home</a>
    </nav>

    <main>
        <form class="register-box" action="" method="POST" enctype="multipart/form-data">
            <h2>Register User</h2>

            <label>Username</label>
            <input type="text" name="Username" placeholder="Username" required>

            <label>Password</label>
            <input type="password" name="Password" placeholder="Password" required>

            <label>Foto</label>
            <div class="upload-box">
                <span><a href="#">Upload a file</a></span><br>
                <small>PNG, JPG up to 2MB</small>
                <input type="file" name="foto" accept="image/png, image/jpeg" required>
            </div>

            <label>Status</label>
            <select name="status" required>
                <option value="">-- Pilih --</option>
                <option value="Siswa">Siswa</option>
                <option value="Guru">Guru</option>
            </select>

            <button type="submit">Register</button>
        </form>
    </main>

    <footer>
        <p>© UKK Tahun Pelajaran 2024/2025.</p>
    </footer>
</body>
</html>
