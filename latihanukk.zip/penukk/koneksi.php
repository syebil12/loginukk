<?php
$koneksi = mysqli_connect("localhost", "root", "", "belajarukk");

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
