<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="\login2.css">
</head>
<body>
    <div class="login-container">
        <form method="POST" action="" class="login-box">
            <img src="LogoRPL.jpeg" alt="" class="logo">
            <p class="subtitle">Mulai Akses Akun User</p>
            <h2>Login user</h2>

            <input id="Usename" type="text" name="Username" placeholder="Username" requireid>
            <input id="Password" type="Password" name="Password" placeholder="Password" requireid>

            <select name="status" id="">
                <option value="">Pilih Peran</option>
                <option value="siswa">Siswa</option>
                <option value="Guru">Guru</option>
                <option value="Guru">Kepala Sekolah</option>
            </select>

            <button type="submit" class="btn-login">Login</button>

            <p class="register-text">Apakah Anda Belum Memiliki Akun User</p>
            <a href="register.php" class="btn-register">Buat Akun User</a>
            <a href="menuutama.php">Balik Ke Home</a>
        </form>
    </div>
</body>
</html>