<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nis         = $_POST['nis'];
    $nomor_tes   = $_POST['nomor_tes'];
    $tanggal_tes = $_POST['tanggal_tes'];
    $bersedia    = $_POST['bersedia'];

    $query = "INSERT INTO tes_siswa (nis, nomor_tes, tanggal_tes, bersedia) 
              VALUES ('$nis', '$nomor_tes', '$tanggal_tes', '$bersedia')";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Data berhasil disimpan'); window.location.href='data_tes.php';</script>";
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>
